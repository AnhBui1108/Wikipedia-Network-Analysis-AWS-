

import pyspark 
from pyspark.storagelevel import StorageLevel
from pyspark.sql import (
    functions as F, 
    types as T,
    SparkSession,
)
from datetime import datetime
import os



print("Staring spark session")

spark = (
    SparkSession.builder
    #.remote('sc://localhost:15002')
    .appName("My App")
    .getOrCreate()
)

from methods import DataIO, create_mutual_links, connected_components, parquet, save



dataIO = DataIO(spark)

t0 = datetime.now()
print("comput the mutual links")
mutual_links = create_mutual_links(
        spark,
        parquet('page'),
        parquet('pagelinks'), 
        parquet('linktarget'), 
        parquet('redirect')
    )

spark.table("mutual_links").count()
dataIO.write(mutual_links, 'mutual_links')
print("running time: " , datetime.now()- t0)



print("The number of mutual links: ", spark.table("mutual_links").count())



spark.table("mutual_links").show()




t2 = datetime.now()
print("start compute the connected component")



cc = connected_components(spark, mutual_links, dataIO,'checkpoint')
cc = cc.select(F.col("src").alias("vertex"),
               F.col("updated_component_ID").alias("component_ID"))
cc.show()

print("conected component stats")
cc_stats = cc.groupBy("component_ID").agg(F.expr("count(*) as size"))
cc_counts = cc_stats.count()

print("The number of conected component: ", cc_counts)
cc_stats.orderBy(F.desc("size")).show(truncate=False)

dataIO.write(cc, 'wikipedia_components')
print("running time", datetime.now() - t2)





